DROP TRIGGER IF EXISTS trg_copy_invitation_to_profile ON public.profiles;
