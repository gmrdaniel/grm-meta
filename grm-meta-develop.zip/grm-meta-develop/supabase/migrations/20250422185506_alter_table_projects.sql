alter table projects
add column slug text unique;