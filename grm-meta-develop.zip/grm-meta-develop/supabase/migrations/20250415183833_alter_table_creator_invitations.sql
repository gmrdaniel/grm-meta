ALTER TABLE creator_invitations
ADD COLUMN stage_updated_at TIMESTAMP WITH TIME ZONE;
