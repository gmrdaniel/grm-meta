ALTER TABLE notification_settings
ADD COLUMN target_status TEXT;