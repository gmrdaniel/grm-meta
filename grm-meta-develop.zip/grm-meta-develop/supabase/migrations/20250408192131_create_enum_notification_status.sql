create type notification_status as enum (
  'sent',
  'failed',
  'pending'
);
