ALTER TABLE creator_invitations
ADD COLUMN facebook_profile TEXT;
