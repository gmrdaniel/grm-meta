ALTER TABLE invitation_events
ADD COLUMN description TEXT,
ADD COLUMN deadline DATE,
ADD COLUMN link_terms TEXT;
