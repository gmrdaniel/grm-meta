-- Enum for communication channels
create type notification_channel as enum (
  'sms',
  'email'
);
