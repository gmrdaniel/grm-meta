CREATE TYPE creator_quality AS ENUM ('low', 'medium', 'high');
