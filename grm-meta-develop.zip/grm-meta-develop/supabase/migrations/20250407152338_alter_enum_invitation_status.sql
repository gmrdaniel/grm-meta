ALTER TYPE invitation_status ADD VALUE IF NOT EXISTS 'sended';
ALTER TYPE invitation_status ADD VALUE IF NOT EXISTS 'in process';
