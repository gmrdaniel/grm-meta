ALTER TABLE "public"."creator_invitations"
DROP CONSTRAINT "creator_invitations_social_media_type_check";
