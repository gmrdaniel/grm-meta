ALTER TABLE public.profiles
ADD COLUMN phone_country_code TEXT,
ADD COLUMN phone_number TEXT;
