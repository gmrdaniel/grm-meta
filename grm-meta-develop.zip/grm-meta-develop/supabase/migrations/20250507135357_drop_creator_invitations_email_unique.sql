ALTER TABLE public.creator_invitations 
DROP CONSTRAINT IF EXISTS creator_invitations_email_unique;
