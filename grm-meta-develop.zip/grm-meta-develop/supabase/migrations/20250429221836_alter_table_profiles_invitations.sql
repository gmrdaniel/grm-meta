ALTER TABLE profiles
ADD COLUMN pinterest_url TEXT;
