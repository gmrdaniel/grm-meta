ALTER TABLE profile_projects
ADD COLUMN fb_profile_id TEXT,
ADD COLUMN fb_profile_owner_id TEXT;