INSERT INTO content_categories (id, key, name_es, name_en)
VALUES
  ('e54e5d2d-2c9c-4a1d-8ab3-d945e2140d7d', 'decoration', 'Decoración', 'Decoration'),
  ('55a91d7f-4b63-40de-b349-87b55d99d82c', 'weddings', 'Bodas', 'Weddings'),
  ('191cd6bb-7e84-41a6-8468-d3e5e3dc5a03', 'recipes', 'Recetas', 'Recipes'),
  ('6fa57ad8-fb35-4c2c-8cb1-07c65fc9e82f', 'fashion', 'Moda', 'Fashion'),
  ('ad328cd1-53c6-4ac4-8c3e-2c0fd2f558e3', 'beauty', 'Belleza', 'Beauty'),
  ('c7a0d9da-3c87-4cb7-bb03-7d3b9fa6512e', 'lifestyle', 'Lifestyle', 'Lifestyle'),
  ('0de276d6-60df-4e1e-9ab0-417ac6f964b2', 'travel', 'Viajes', 'Travel'),
  ('73949ec5-5b1f-4dc2-bc76-0d4fdbd81cc3', 'wellness', 'Bienestar', 'Wellness'),
  ('4f11c3f9-2218-4a4f-9064-2187a92e4e58', 'other', 'Otros', 'Other');