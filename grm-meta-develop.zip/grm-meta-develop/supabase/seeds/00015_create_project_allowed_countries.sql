-- Asociar países faltantes al proyecto b1e23456-7f89-4abc-9d12-34567890abcd
INSERT INTO public.project_allowed_countries (project_id, country_id)
VALUES
('b1e23456-7f89-4abc-9d12-34567890abcd', 'e504963e-6bb1-4b91-9f7d-927f75f451b8'), -- USA
('b1e23456-7f89-4abc-9d12-34567890abcd', '3fc5c208-fac3-4f13-94dc-92ae60be0c01'), -- Bolivia
('b1e23456-7f89-4abc-9d12-34567890abcd', '0f2a942a-5e36-4325-80f3-1ae6c9c11b87'), -- Costa Rica
('b1e23456-7f89-4abc-9d12-34567890abcd', 'b118be03-0501-4211-81e1-d362c612bc8c'), -- Ecuador
('b1e23456-7f89-4abc-9d12-34567890abcd', '8e2a2d65-2303-4644-996d-88c289e91db5'), -- El Salvador
('b1e23456-7f89-4abc-9d12-34567890abcd', 'e7d6b9c1-8ff6-4ec7-b87b-3a314a6d297f'), -- Guatemala
('b1e23456-7f89-4abc-9d12-34567890abcd', 'd1b34b59-e8bc-49aa-bc94-40cf6231db1d'), -- Honduras
('b1e23456-7f89-4abc-9d12-34567890abcd', '4e5c9f16-6799-4307-9f3f-d0e9a0cb1c84'), -- Nicaragua
('b1e23456-7f89-4abc-9d12-34567890abcd', '624b9df2-82d9-404e-b7b2-e18dc3a5ee39'), -- Panamá
('b1e23456-7f89-4abc-9d12-34567890abcd', 'a67b7b2c-2b1b-44b4-93f2-9206a154bfc1'), -- Paraguay
('b1e23456-7f89-4abc-9d12-34567890abcd', 'd44d7583-c770-4a42-a7d7-219fd25e0a69'), -- República Dominicana
('b1e23456-7f89-4abc-9d12-34567890abcd', '2f4d4434-771e-4958-a54e-e46c54e5652e'), -- Uruguay
('b1e23456-7f89-4abc-9d12-34567890abcd', 'd72c2322-5865-470e-9e01-5c94b6d4a414'); -- Venezuela
