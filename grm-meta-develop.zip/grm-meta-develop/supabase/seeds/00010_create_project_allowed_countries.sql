-- Proyecto Meta
INSERT INTO public.project_allowed_countries (project_id, country_id)
VALUES
('cf7f3465-2b30-4cb7-8b55-c5ab10b00505', 'e504963e-6bb1-4b91-9f7d-927f75f451b8'); -- USA

-- Proyecto Pinterest
INSERT INTO public.project_allowed_countries (project_id, country_id)
VALUES
('b1e23456-7f89-4abc-9d12-34567890abcd', 'be1e04cb-bb0f-41fc-9b64-1e82d08461a5'), -- México
('b1e23456-7f89-4abc-9d12-34567890abcd', '4c3b2f80-88b5-42a5-8aa6-d75856cfbe94'), -- Colombia
('b1e23456-7f89-4abc-9d12-34567890abcd', 'f4a8379e-9631-44d3-805d-20345bfa3e43'), -- Argentina
('b1e23456-7f89-4abc-9d12-34567890abcd', '6ebc60ab-0896-4bc7-9532-2ad98e44ea72'), -- Chile
('b1e23456-7f89-4abc-9d12-34567890abcd', '0b08f1b4-1d79-4e2d-8e88-c19b14c445b5'); -- Perú
