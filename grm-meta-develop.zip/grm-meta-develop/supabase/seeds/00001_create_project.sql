INSERT INTO
    "public"."projects" (
        "id",
        "name",
        "slug",
        "status",
        "created_at",
        "updated_at"
    )
VALUES
    (
        'cf7f3465-2b30-4cb7-8b55-c5ab10b00505',
        'Meta',
        'meta',
        'active',
        '2025-03-20 03:55:06.575655+00',
        '2025-03-20 03:55:06.575655+00'
    );