
import { Button } from "@/components/ui/button";

export const EmptyStateCard = () => {
  return (
    <div className="p-8 text-center">
      <p className="text-muted-foreground">No notification settings found</p>
      <Button variant="outline" className="mt-4" onClick={() => window.location.hash = "#new"}>
        Create your first notification setting
      </Button>
    </div>
  );
};