export type EmailTemplate = {
    html: string;
};