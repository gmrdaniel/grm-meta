export type ContentCategory = {
  id: string;
  key: string;
  name_es: string;
  name_en: string;
};
