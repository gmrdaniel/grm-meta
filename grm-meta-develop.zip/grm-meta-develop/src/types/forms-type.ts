export interface ProfileFormData {
    youtubeChannel: string;
    phoneCountryCode: string;
    phoneNumber: string;
    phoneVerified: boolean;
  }